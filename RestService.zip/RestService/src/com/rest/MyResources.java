package com.rest;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

@Path("/myresource")
public class MyResources {
	

	@Path("/msg")
    @GET
    @Produces("text/html")
	public String getIt() {
		return "<h1> Hi There! </h1>";
	}
	
	@Path("/name")
	@GET
	@Produces("text/html")
	public String name() {
		return "<h1> Ronaldo </h1>";
	}
	
	@Path("/sum")
	@GET
	@Produces("text/html")
	public String SumInt() {
		int a = 5;
		int b = 7;
		int c = a  +b;
		return ("<h1>" + c + "</h1>");
	}
	
}
