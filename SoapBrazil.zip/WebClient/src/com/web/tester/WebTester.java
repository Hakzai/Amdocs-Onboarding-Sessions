package com.web.tester;

import com.web.PersonImpl;
import com.web.PersonImplService;

public class WebTester {

	public static void main(String args[]) {
		PersonImplService service = new PersonImplService();
		
		PersonImpl object = service.getPersonImpl();
		System.out.println(object.getPersonInfo());
	}
}
