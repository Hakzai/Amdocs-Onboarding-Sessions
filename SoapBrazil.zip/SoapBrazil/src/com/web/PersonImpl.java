package com.web;

public class PersonImpl implements Person{
	
	@Override
	public String getPersonInfo() {
		
		return "getting person info...";
	}

}
