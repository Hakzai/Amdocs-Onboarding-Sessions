package com.web;

public interface Person {
	
	public String getPersonInfo();
}
