package com.training.spring;

import org.springframework.beans.factory.annotation.Autowired;

public class Person {
	
	@Autowired
	Car car;
	
	// Autowired has the same purpose than >> Car car = new Car();
	
	public void getCarInfo() {
		car.getInfo();
	}
}
