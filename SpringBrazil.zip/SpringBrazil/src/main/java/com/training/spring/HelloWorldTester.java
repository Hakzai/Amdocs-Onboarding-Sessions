package com.training.spring;

import org.springframework.context.*;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class HelloWorldTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
        HelloWorld obj = (HelloWorld) context.getBean("helloWorld");
        
        Person person = (Person) context.getBean("person");
        person.getCarInfo();
       //  System.out.println(obj.getMessage());
	}

}
