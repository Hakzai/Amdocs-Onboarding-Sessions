package com.training.spring;

public class Car {
	
	public void getInfo() {
		System.out.println("Getting car info...");
	}
}
