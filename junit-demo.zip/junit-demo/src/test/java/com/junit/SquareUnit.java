package com.junit;

import static org.junit.Assert.*;

import org.junit.Test;

public class SquareUnit {

	@Test
	public void test() {
		MyClass obj = new MyClass();
        int output = obj.getSquare(3);
        assertEquals(9, output);
        System.out.println("The value of output " + output);
	}

}
