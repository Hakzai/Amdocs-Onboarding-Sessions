package com.junit;

import static org.junit.Assert.*;

import org.junit.Test;

public class SumUnit {

	@Test
	public void test() {
		MyClass obj = new MyClass();
        int output = obj.getSum(3, 5);
        assertEquals(8, output);
	}

}
