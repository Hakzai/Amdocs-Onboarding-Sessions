package com.assignment.four.exOne;

public class Developer {
	
	private int emp_no;
	private String name;
	private String project_name;
	private String phone_no;
	
	public Developer(){
		
	}
	
	public Developer(int emp_no, String name, String project_name, String phone_no){
		this.emp_no = emp_no;
		this.name = name;
		this.project_name = project_name;
		this.phone_no = phone_no;
	}

	public int getEmp_no() {
		return emp_no;
	}

	public void setEmp_no(int emp_no) {
		this.emp_no = emp_no;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getProject_name() {
		return project_name;
	}

	public void setProject_name(String project_name) {
		this.project_name = project_name;
	}

	public String getPhone_no() {
		return phone_no;
	}

	public void setPhone_no(String phone_no) {
		this.phone_no = phone_no;
	}
}
