package com.assignment.four.exOne;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	
	public static void main (String args[]){
		Scanner s = new Scanner(System.in);
		
		// CREATE ARRAYLIST AND INSERT DATA
		ArrayList<Developer> dev = new ArrayList<>();
		dev.add(new Developer(123, "Isaac", "CALA", "988357958"));
		dev.add(new Developer(234, "Tiago", "NASA", "981309187"));
		dev.add(new Developer(345, "Maria", "UNIX", "994156326"));
		dev.add(new Developer(456, "John", "CALA", "999621684"));
				
		// WELCOME MESSAGE
		System.out.println("*WELCOME TO THE ENTERPRISE SYSTEM*");

		int getId = -1;
		while(getId!=0){
			// GET EMPLOYEE NO
			System.out.print("\nEnter the employee ID: ");
			getId = Integer.parseInt(s.next());
			
			// PRINT DEVELOPER DATA
			for(Developer developer : dev){
				if(developer.getEmp_no() == getId){
					System.out.println("  FOUND! \n\nEmployee ID: " + developer.getEmp_no() 
							+ "\nEmployee Name: " + developer.getName()
							+ "\nProject: " + developer.getProject_name() 
							+ "\nPhone: " + developer.getPhone_no());
					
					// IF -1 NOT SENDING ERROR
					getId = -1;
				}
			}
			// PRINT ERROR
			if(getId != -1){
				System.out.println("  EMPLOYEE NOT FOUND!");
			}
		
		}
		
		System.out.println("*END OF RUNNING*");
		s.close();
	}
}
