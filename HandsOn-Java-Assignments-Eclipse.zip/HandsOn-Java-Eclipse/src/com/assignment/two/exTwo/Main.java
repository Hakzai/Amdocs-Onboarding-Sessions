package com.assignment.two.exTwo;

import java.util.Scanner;

public class Main {
	
	public static void main (String args[]){
		
		Scanner s = new Scanner(System.in);
		Employee emp = new Employee();
	
		System.out.println("Add data to Employee \n");
		
		System.out.print("Enter ID: ");
		emp.emp_no = Integer.parseInt(s.nextLine());
		System.out.print("Enter name: ");
		emp.name = s.nextLine();
		System.out.print("Enter address: ");
		emp.address = s.nextLine();
		System.out.print("Enter Salary: $");
		emp.salary = Double.parseDouble(s.nextLine());
		System.out.print("Enter designation: ");
		emp.designation = s.nextLine();
		System.out.print("Enter department: ");
		emp.department = s.nextLine();
		
		System.out.print("\nEmployee ID: " + emp.emp_no + "\nName: " + emp.name + 
					"\nAddress: " + emp.address + "\nSalary: " + emp.salary + 
				"\nDesignation: " + emp.designation + "\nDepartment: " + emp.department);
		
		s.close();
		
	}
}
