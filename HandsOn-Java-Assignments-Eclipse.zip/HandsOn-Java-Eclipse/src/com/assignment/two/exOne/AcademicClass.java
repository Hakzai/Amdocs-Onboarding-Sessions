package com.assignment.two.exOne;

public class AcademicClass {
	
	float physics_mark = 8.5f;
	float chemistry_mark = 6.5f ;
	float biology_mark = 8;
	float total = (physics_mark + chemistry_mark + biology_mark)/3;
	
	private Student student;

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public AcademicClass(){
	}
}
