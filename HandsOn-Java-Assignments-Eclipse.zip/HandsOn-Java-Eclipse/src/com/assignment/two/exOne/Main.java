package com.assignment.two.exOne;

public class Main{

	public static void main(String[] args) {
		
		AcademicClass cl = new AcademicClass();
		Student student = new Student();

		student.roll_no = 123;
		student.name = "Isaac";
		student.email = "isaac@college.com";
		student.phone_no = "988357958";
		
		cl.setStudent(student);
		
		System.out.println("Student '" + cl.getStudent().name + "' data and marks \n");
		
		System.out.println("Roll: " + cl.getStudent().roll_no);
		System.out.println("name: " +  cl.getStudent().name);
		System.out.println("email: " + cl.getStudent().email);
		System.out.println("Phone: " + cl.getStudent().phone_no + "\n");
		
		System.out.println("Marks \n Physics: " +  cl.physics_mark
							+	"\n Biology: " + cl.biology_mark
							+	"\n Chemistry: " + cl.chemistry_mark
							+	"\n Total " + cl.total);

	}

}
