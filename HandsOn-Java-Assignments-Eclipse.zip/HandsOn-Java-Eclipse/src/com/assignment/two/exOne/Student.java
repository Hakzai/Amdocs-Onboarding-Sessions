package com.assignment.two.exOne;

public class Student{
	int roll_no;
	String name;
	String email;
	String phone_no;
	
	public Student(){
	}

}
