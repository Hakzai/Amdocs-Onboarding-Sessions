package com.assignment.three.exOne;

import java.util.Scanner;

public class Main{
	
	public static void main (String args[]){
		Scanner s = new Scanner(System.in);
		
		// CREATE ARRAY AND INITIATE OBJECTS
		Bank[] acc = new Bank[3];
		acc[0] = new Bank(217, "Isaac", 500.32, "988357958");
		acc[1] = new Bank(295, "Tiago", 23660.99, "994156326");
		acc[2] = new Bank(348, "Paulo", -233.40, "981309187");
				
		// WELCOME MESSAGE
		System.out.println("*WELCOME TO THE BANK SYSTEM*");

		// GET ACCOUNT NO
		System.out.print("\nYour account no: ");
		int getAccount = Integer.parseInt(s.next());
		int getIndex = 0;
		int option = 0;
		
		// SEARCH FOR ACCOUNT
		for(int i=0;i<acc.length;i++){
			if(getAccount == acc[i].getAccount_no()){
				System.out.println("\nFOUND! \nWelcome " + acc[i].getName());
				getIndex = i;
				option = -1;
				break;
			}
		}
		
		// FINISH THE PROGRAM IF NOT FOUND
		if(option!=-1)
			System.out.println("\n\tCan't find your Account! Please Try again!");
				
		// OPEN MENU IF FOUND
		while(option != 0){
			System.out.println("\nSelect your option:");
			System.out.print("1- Deposit \n2- Withdraw \n3- Check Balance \n0- Exit \n\n>> ");			
			
			option = Integer.parseInt(s.next());
			
			//DEPOSIT
			if(option==1){
				System.out.print("Deposit Ammount: $");
				double ammount = Double.parseDouble(s.next());
				System.out.println("New account balance: $" +acc[getIndex].deposit(ammount));
			}
			
			// WITHDRAW
			else if(option==2){
				System.out.print("Withdraw Ammount: $");
				double ammount = Double.parseDouble(s.next());
				if((acc[getIndex].getBalance()-ammount)<0)
					System.out.println("\n\tYour withdraw request is bigger than your balance. Please retry!");
				else
					System.out.println("New account balance: $" +acc[getIndex].withdraw(ammount));
			}
			
			// CHECK BALANCE
			else if(option==3){
				System.out.println("\nAccount balance: $" +acc[getIndex].getBalance());
			}
			
			// ERROR
			else{
				if(option!=0)
					System.out.println("\n\tPLEASE SELECT A VALID OPTION!");
			}
			
			// ZERO QUITS THE PROGRAM
		}
		
		s.close();
		System.out.print("*\nEND OF PROGRAM*");

	}
}