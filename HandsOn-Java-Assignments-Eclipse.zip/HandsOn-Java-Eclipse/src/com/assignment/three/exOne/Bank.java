package com.assignment.three.exOne;

public class Bank {
	private int account_no;
	private String name;
	private double balance;
	private String phone_no;
	
	public Bank (){
		
	}
	
	public Bank(int acc, String name, double bal, String phone) {
		this.account_no = acc;
		this.name = name;
		this.balance = bal;
		this.phone_no = phone;
	}

	public double withdraw (double ammount){
		return balance = balance-ammount;
	}
	
	public double deposit (double ammount){
		return balance = balance+ammount;
	}

	public int getAccount_no() {
		return account_no;
	}

	public void setAccount_no(int account_no) {
		this.account_no = account_no;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getPhone_no() {
		return phone_no;
	}

	public void setPhone_no(String phone_no) {
		this.phone_no = phone_no;
	}
	
	

}
