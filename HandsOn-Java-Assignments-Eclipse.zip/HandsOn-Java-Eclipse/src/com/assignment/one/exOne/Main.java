package com.assignment.one.exOne;

public class Main{

	public static void main(String[] args) {
		
		Student student = new Student();
		
		System.out.println("Student '" + student.name + "' data and marks \n");
		
		System.out.println("Roll: " + student.roll_no);
		System.out.println("name: " + student.name);
		System.out.println("email: " + student.email);
		System.out.println("Phone: " + student.phone_no + "\n");
		
		System.out.println("Marks \n Physics: " + student.physics_mark
							+	"\n Biology: " + student.biology_mark
							+	"\n Chemistry: " + student.chemistry_mark
							+	"\n Total " + student.total);

	}

}
