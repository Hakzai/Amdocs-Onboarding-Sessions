package com.assignment.one.exOne;

public class Student extends AcademicClass{
	protected int roll_no = 123;
	protected String name = "Isaac";
	protected String email = "isaac@college.com";
	protected String phone_no = "988357958";
	
	public Student(){
		super();
	}

}
