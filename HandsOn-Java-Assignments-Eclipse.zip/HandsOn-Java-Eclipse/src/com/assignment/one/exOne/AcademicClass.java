package com.assignment.one.exOne;

public class AcademicClass {
	
	protected float physics_mark = 8.5f;
	protected float chemistry_mark = 6.5f ;
	protected float biology_mark = 8;
	protected float total = (physics_mark + chemistry_mark + biology_mark)/3;
	
	public AcademicClass(){
	}
}
