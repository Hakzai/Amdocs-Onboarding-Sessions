package com.assignment.one.exTwo;

public class Employee {
	
	int emp_no;
	String name;
	String address;
	double salary;
	String designation;
	String department;
	
	public Employee(){
		
	}
}
