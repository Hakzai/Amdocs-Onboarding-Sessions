-- OBSERVAÇÕES IMPORTANTES
/*
	- Criar o banco de dados utilizando algum servidor MySQL (neste caso estamos usando o WampSERVER)
	- No WampSERVER o padrão da porta MySQL é localhost:3308/ ao invés de 3306
	- Utilizar o Workbench (ou qualquer outro software) para configurar o acesso ao banco de dados
	 >> Importante que seja localhost ao invés do IP.
	- Sempre fazer o 'force update' do Eclipse para instalar as dependencies do Maven
	- (dica) Utilizar o Visual Studio Code para modelar o CSS
*/

CREATE DATABASE test; -- DATABASE PADRÃO DO NOSSO SPRING MVC

USE test;

CREATE TABLE Employee (
	ID INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    NAME VARCHAR(50) NOT NULL,
    SALARY FLOAT NOT NULL,
    DESIGNATION VARCHAR(20)
    );

DESC EMPLOYEE;

-- SOMENTE UTILIZAR ESSAS ALTERAÇÕES DE VARIÁVEIS NO MYSQL CASO O CONNECT DO JAVA DER ALGUM ERRO REFERENTE AO 'TIMEZONE'

/*

SET @@global.time_zone = '-3:00';

Select now();

Set @@global.system_time_zone = '-3:00';
*/